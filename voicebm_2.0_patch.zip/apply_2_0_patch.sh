#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# VoiceBM Active 2.0 Patch Applier  (F-01 / F-02 / F-03 / F-04)
# -----------------------------------------------------------------------------
# Applies the Active 2.0 additions to an EXISTING 1.0 install, the same way the
# repo deploy works: it RENDERS the shipped .template files using the values in
# THIS machine's config.json (no credentials or paths are baked into the patch),
# then installs the rendered host services and copies the Docker handler in.
#
# Run FROM the directory that contains the 2.0 .template files + this script.
# Run as the user that owns the VoiceBM tree (e.g. ice). Uses sudo only for the
# Docker handler copy + restart and the systemd restarts.
#
# NOTHING is deleted. Live files are copied to a timestamped backup dir; the
# printed one-liner rolls everything back.
#
# Files patched (host, rendered from config.json -> VOICEBM_BASE and bin/):
#   voicebm_config.py, voicebm_stt_service.py, mqtt_commands.py,
#   enrollment_watcher.py
# Plus the Docker handler (handler.py) via docker cp (never rebuilt).
# =============================================================================

# --- Locate config.json (single source of truth for paths + credentials) ----
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

find_config() {
  # Allow override: CONFIG_FILE=/path ./apply_2_0_patch.sh
  if [[ -n "${CONFIG_FILE:-}" && -f "${CONFIG_FILE}" ]]; then echo "${CONFIG_FILE}"; return; fi
  for c in "${SRC_DIR}/config.json" "${SRC_DIR}/../config.json" "/home/${SUDO_USER:-$(whoami)}/voicebm/config.json"; do
    [[ -f "$c" ]] && { echo "$c"; return; }
  done
  return 1
}

CONFIG_FILE="$(find_config)" || {
  echo "ERROR: config.json not found. Set CONFIG_FILE=/path/to/config.json and re-run." >&2
  exit 1
}
echo "Using config.json: ${CONFIG_FILE}"

# --- Pull values from config.json (same keys the repo deploy uses) -----------
jget() { python3 -c "import json,sys; print(json.load(open('${CONFIG_FILE}'))${1})"; }

VOICEBM_BASE="$(jget "['paths']['voicebm_base']")"
SHERPA_BIN="$(jget "['paths'].get('sherpa_bin','')" 2>/dev/null || echo "")"
ENROLL_DIR="$(jget "['paths'].get('enroll_dir','${VOICEBM_BASE}/enroll')" 2>/dev/null || echo "${VOICEBM_BASE}/enroll")"

# Install user (real user, not root)
INSTALL_USER="${SUDO_USER:-$(whoami)}"

BIN_DIR="${VOICEBM_BASE}/bin"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="${VOICEBM_BASE}/backups/patch_2.0_${STAMP}"

# Docker handler (NOT rebuilt - only handler.py is copied in)
DOCKER_CONTAINER="nifty_grothendieck"
DOCKER_HANDLER_DST="/app/wyoming_onnx_asr/handler.py"
HANDLER_HOST_SRC="/home/${INSTALL_USER}/onnx-asr-addon/onnx-asr/handler.py"

# Map: template filename -> install location (rendered)
declare -A HOST_TEMPLATES=(
  ["voicebm_config.py.template"]="${VOICEBM_BASE}/voicebm_config.py"
  ["voicebm_stt_service.py.template"]="${BIN_DIR}/voicebm_stt_service.py"
  ["mqtt_commands.py.template"]="${BIN_DIR}/mqtt_commands.py"
  ["enrollment_watcher.py.template"]="${BIN_DIR}/enrollment_watcher.py"
)

RESTART_SERVICES=(
  "voicebm-stt.service"
  "voicebm-commands.service"
  "voicebm-enrollment-watcher.service"
)

echo "=========================================================="
echo " VoiceBM Active 2.0 patch"
echo " VOICEBM_BASE : ${VOICEBM_BASE}"
echo " Backup dir   : ${BACKUP_DIR}"
echo "=========================================================="

# --- 0. Sanity: all source templates present --------------------------------
MISSING=0
for f in "${!HOST_TEMPLATES[@]}" handler.py; do
  [[ -f "${SRC_DIR}/${f}" ]] || { echo "  MISSING source: ${SRC_DIR}/${f}"; MISSING=1; }
done
[[ "${MISSING}" -eq 1 ]] && { echo "Aborting - source files incomplete."; exit 1; }

# --- sed escaping (same approach as repo deploy) ----------------------------
escape_sed() { echo "$1" | sed -e 's/[\/&]/\\&/g'; }
VOICEBM_BASE_ESC="$(escape_sed "${VOICEBM_BASE}")"
SHERPA_BIN_ESC="$(escape_sed "${SHERPA_BIN}")"
ENROLL_DIR_ESC="$(escape_sed "${ENROLL_DIR}")"

render_template() {
  local tpl="$1" out="$2"
  sed -e "s|{VOICEBM_BASE}|${VOICEBM_BASE_ESC}|g" \
      -e "s|{SHERPA_BIN}|${SHERPA_BIN_ESC}|g" \
      -e "s|{ENROLL_DIR}|${ENROLL_DIR_ESC}|g" \
      "${tpl}" > "${out}"
}

# --- 1. Backup --------------------------------------------------------------
mkdir -p "${BACKUP_DIR}"
echo ""
echo "[1/5] Backing up live files..."
for f in "${!HOST_TEMPLATES[@]}"; do
  dst="${HOST_TEMPLATES[$f]}"
  if [[ -f "${dst}" ]]; then
    cp -p "${dst}" "${BACKUP_DIR}/$(basename "${dst}")"
    echo "  saved ${dst}"
  else
    echo "  (no existing ${dst} - first install of this file)"
  fi
done
if sudo docker exec "${DOCKER_CONTAINER}" test -f "${DOCKER_HANDLER_DST}" 2>/dev/null; then
  sudo docker cp "${DOCKER_CONTAINER}:${DOCKER_HANDLER_DST}" "${BACKUP_DIR}/handler.py" || true
  echo "  saved (docker) ${DOCKER_HANDLER_DST}"
fi

# --- 2. Render + install host files -----------------------------------------
echo ""
echo "[2/5] Rendering host files from config.json and installing..."
mkdir -p "${BIN_DIR}"
for f in "${!HOST_TEMPLATES[@]}"; do
  dst="${HOST_TEMPLATES[$f]}"
  tmp="$(mktemp)"
  render_template "${SRC_DIR}/${f}" "${tmp}"
  install -m 0644 "${tmp}" "${dst}"
  rm -f "${tmp}"
  chown "${INSTALL_USER}:${INSTALL_USER}" "${dst}" 2>/dev/null || true
  echo "  installed ${dst}"
done

# --- 3. Ensure config.json carries the 2.0 voicebm tunables -----------------
echo ""
echo "[3/5] Ensuring config.json has the voicebm tunables (defaults; non-destructive)..."
python3 - "${CONFIG_FILE}" <<'PYEOF'
import json, sys
p = sys.argv[1]
with open(p) as f:
    cfg = json.load(f)
vb = cfg.get("voicebm", {})
changed = False
# Defaults match the shipped config module; do NOT overwrite existing values.
if "gallery_max" not in vb:
    vb["gallery_max"] = 75; changed = True
if "active_lead_trim_ms" not in vb:
    vb["active_lead_trim_ms"] = 0; changed = True
if changed:
    cfg["voicebm"] = vb
    with open(p, "w") as f:
        json.dump(cfg, f, indent=2)
    print(f"  added voicebm defaults: {vb}")
else:
    print(f"  voicebm section already present: {vb}")
PYEOF

# --- 4. Restart host services -----------------------------------------------
echo ""
echo "[4/5] Restarting host services..."
for svc in "${RESTART_SERVICES[@]}"; do
  if systemctl list-unit-files | grep -q "^${svc}"; then
    sudo systemctl restart "${svc}"
    echo "  restarted ${svc}"
  else
    echo "  (skip ${svc} - not installed)"
  fi
done

# --- 5. Update Docker handler (copy + restart only - never rebuilt) ---------
echo ""
echo "[5/5] Updating Docker handler.py..."
mkdir -p "$(dirname "${HANDLER_HOST_SRC}")"
install -m 0644 "${SRC_DIR}/handler.py" "${HANDLER_HOST_SRC}"
echo "  staged ${HANDLER_HOST_SRC}"
sudo docker cp "${HANDLER_HOST_SRC}" "${DOCKER_CONTAINER}:${DOCKER_HANDLER_DST}"
sudo docker restart "${DOCKER_CONTAINER}"
echo "  copied into ${DOCKER_CONTAINER} and restarted"

echo ""
echo "=========================================================="
echo " DONE."
echo ""
echo " Rollback (everything):"
for f in "${!HOST_TEMPLATES[@]}"; do
  dst="${HOST_TEMPLATES[$f]}"
  echo "   cp ${BACKUP_DIR}/$(basename "${dst}") ${dst}"
done
echo "   # then: sudo systemctl restart ${RESTART_SERVICES[*]}"
echo "   # docker handler:"
echo "   sudo docker cp ${BACKUP_DIR}/handler.py ${DOCKER_CONTAINER}:${DOCKER_HANDLER_DST} && sudo docker restart ${DOCKER_CONTAINER}"
echo "=========================================================="
