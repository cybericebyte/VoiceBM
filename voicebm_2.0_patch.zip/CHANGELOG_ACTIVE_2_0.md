# VoiceBM Active 2.0 — Changelog & Migration Guide

**Scope: the active / global side only.**

VoiceBM is split into two independently-deployable sides: the **active/global**
side (`templates/global/` — live STT, identity resolution, enrollment, MQTT
discovery; deployed via `deploy_global_services.sh`) and the **passive** side
(`templates/passive/` — per-room recorders, embedders, scorers, clustering;
deployed via `replicate_node.sh`). Either side can be installed without the
other.

Everything in this release is on the **active/global** side. The passive side is
unchanged and continues at its existing version; it will get its own 2.0 when
passive-side work is done. This document versions the active side as **Active
2.0**.

Active 2.0 builds on the 1.0 Sherpa release. It adds new capability on top of a
running 1.0 install: a new clean gate-enforced transcript broadcast for
automation consumption, a per-person gallery rollover cap, an aggregate blocklist
topic, a configurable active-pipeline lead trim, and the `user` fallback display
name. These are additions, not fixes — 1.0 keeps working; 2.0 layers more on top.

**Active 2.0 contains one breaking change** (the raw transcript topic was
renamed, below). Read the Breaking Changes section before upgrading an existing
install.

---

## Breaking Changes

### The original transcript topic was renamed, and a new clean topic was added

1.0 published a single transcript broadcast. It was a raw feed — everything,
including noise triggers and results for blocked speakers — so every consuming
automation had to do its own tag-stripping and blocklist re-checking ("the song
and dance") because the topic made no guarantees about what it carried.

2.0 does **not** change what that raw feed does. It keeps the raw broadcast (now
under the name `voicebm/transcript/debug`) and **adds a second, separate topic**,
`voicebm/transcript/preferred`, that does something different: it carries only
gate-enforced output.

| Topic | What it is | Use it for |
|-------|------------|------------|
| `voicebm/transcript/debug` | The original raw broadcast, renamed. Always-on, published whenever a transcript is produced for a non-blocked speaker. Enforces nothing. Same behavior as the 1.0 topic. | Diagnostics. |
| `voicebm/transcript/preferred` | **New in 2.0.** Clean, gate-enforced output. Carries the transcript only when the speaker passed the blocklist gate; if the speaker was blocked, it is cleared to an empty payload. No identity tag. | **New automations should consume this.** |

Notes on actual behavior:

- The **preferred** topic is published from the handler in two places: cleared to
  `""` on the blocked path, and carrying the transcript text on the allowed path.
  That is what "gate-enforced" means — a blocked speaker yields an empty payload.
- The **debug** topic is published only on the non-blocked path, with the full
  JSON message — the same thing the 1.0 feed did. It is not cleared on block.

#### What you must do when upgrading

The only behavior change is the **rename** of the raw feed. Anything that
subscribed to the old 1.0 transcript topic must repoint to
`voicebm/transcript/debug` to keep the identical raw feed, or to
`voicebm/transcript/preferred` if you want the new gate-enforced text instead.
The `preferred` topic is brand new, so nothing was consuming it before.

---

## New Features

### Gallery rollover cap (per-person sample limit)

A configurable per-person ceiling on enrolled embeddings. When a new enrollment
would push a person over the cap, the **oldest** sample (by `enrolled_at`) is
pruned — its embedding `.txt` and recording `.wav` are deleted and the metadata
is updated. This is the drift control for auto-enrollment: a person's voiceprint
adapts over time as old samples age out instead of the gallery growing without
bound.

- Exposed in Home Assistant as the **Gallery Max** number entity on the Voice
  Biometrics device.
- Command topic `voicebm/gallery_max/set`, state topic `voicebm/gallery_max`
  (retained).
- **The active STT service reads the cap from `thresholds.json` (`GALLERY_MAX`),
  which the Home Assistant slider writes.** Its default is **0 (no rollover)** —
  existing behavior is unchanged until you set a value. The slider change is read
  back on every enrollment, so VoiceBM always enforces the current setting.
- Enforced on both enrollment paths (active pending-enroll in the STT service and
  the label/enroll path in the command listener), each using a self-contained
  copy of the cap logic so the two services stay independent.

### Active-pipeline lead trim (wake-chime trim)

The embedding step can strip a configurable amount of audio from the **front** of
the audio before embedding, so a wake-word chime is kept out of the sample that
gets embedded for matching and enrollment. The voiceprint is weighted toward the
speaker's voice instead of the chime.

- The trim happens at the embedding chokepoint (`create_embedding`): a trimmed
  temp copy is embedded and then deleted. **The stored WAV is never modified** —
  only the embedding input is trimmed. This single chokepoint covers both
  identity matching and pending enrollment.
- The amount is **configurable in milliseconds** via `config.json`
  (`voicebm.active_lead_trim_ms`), exposed in Home Assistant as the **Active Lead
  Trim** number entity (command topic `voicebm/active/lead_trim/set`, state topic
  `voicebm/active/lead_trim`). A slider change persists to `config.json`.
- **Default is 0 (off).** No trimming happens until a non-zero value is set. Set
  it to roughly the length of your wake-word chime if you want it active.

### Aggregate blocklist topic

1.0 published blocklist state only per person, under
`voicebm/blocklist/{person_id}`, with no single place to read the whole list.

2.0 adds an aggregate **Blocklist State** sensor backed by a single topic:

```
voicebm/blocklist_state
```

Published by `enrollment_watcher.py`, it carries the full
`{person_id: blocked}` map as JSON. The sensor's state shows the count currently
blocked; the complete map is exposed as attributes for automation consumption.
The per-person topics are unchanged and continue to work. The aggregate topic is
deliberately **not** under `voicebm/blocklist/+`, so it never collides with the
per-person state subscribers.

### Fallback identity display name is now "user"

The fallback (virtual) identity for unmatched speakers now reports its
`display_name` as **`user`** instead of `Unknown`.

`user` *is* the unknown speaker by definition, and the literal string "Unknown"
created friction in every automation that consumed identity (extra
special-casing, ambiguous matches). Standardizing on `user` removes that
overhead and makes the fallback identity behave like any other enrolled identity.

> The "Detected / Unknown" voice-activity binary sensor is unrelated — that label
> describes whether speech was detected, not an identity, and is unchanged.

---

## Summary table

| ID | Type | Item | Status |
|----|------|------|--------|
| F-01 | Feature | New `voicebm/transcript/preferred` (gate-enforced); original raw feed renamed to `voicebm/transcript/debug` | Added (rename is breaking) |
| F-02 | Feature | Configurable lead trim at the embedding chokepoint (keeps a wake-word chime out of the embedded sample) | Added (default off) |
| F-03 | Feature | Aggregate blocklist topic `voicebm/blocklist_state` | Added |
| F-04 | Feature | Fallback `display_name` is now `user` instead of `Unknown` | Added |

---

## Upgrade checklist (Active 1.0 → Active 2.0)

1. **Deploy the 2.0 service files** (`handler.py` into the Docker container via
   `docker cp` + restart; the host Python services into `/home/ice/voicebm/bin/`
   and restart their units).
2. **Repoint transcript consumers.** Anything that consumed the old single
   transcript topic should move to `voicebm/transcript/preferred` (recommended,
   gate-enforced) or `voicebm/transcript/debug` (raw). New automations should use
   `voicebm/transcript/preferred`.
3. **(Optional) Set Gallery Max** in Home Assistant if you want rollover. Default
   is 0 (no rollover); behavior is unchanged until you set a value.
4. **(Optional) Set Active Lead Trim** in Home Assistant if you want the wake-chime
   stripped from the embedding. Default is 0 (off); no trimming happens until you
   set a non-zero millisecond value.
5. The aggregate **Blocklist State** sensor and the `user` display-name change
   require no action — they appear automatically.

Fresh installs get all of the above configured through the normal deployment
flow; no migration steps apply.
