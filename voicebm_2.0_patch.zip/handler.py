"""Event handler for clients of the server with Voice Biometrics integration via MQTT.

ACTIVE PIPELINE SCRIPT - Docker container component
This runs inside the ONNX ASR Docker container (<container>)

CRITICAL FLOW ORDER:
1. Audio comes in
2. Voice biometrics analysis FIRST (identify speaker from gallery)
3. Fire binary sensor (ALWAYS, regardless of blocklist)
4. Update current_speaker text sensor with gallery match
5. If blocked: STOP - No STT, No MQTT publish, just return empty transcript
6. If not blocked: Do STT, apply injection, publish to MQTT

Deploy via:
  sudo docker cp <host>/onnx-asr-addon/onnx-asr/handler.py <container>:/app/wyoming_onnx_asr/handler.py
  sudo docker restart <container>
"""

import asyncio
import logging
import os
import tempfile
import wave
import json
import time
import uuid
import shutil
from pathlib import Path

from typing import Optional
import numpy as np
import soundfile as sf
from onnx_asr.adapters import AsrAdapter
from wyoming.asr import Transcribe, Transcript
from wyoming.audio import AudioChunk, AudioStop
from wyoming.event import Event
from wyoming.info import Describe, Info
from wyoming.server import AsyncEventHandler
import paho.mqtt.client as mqtt

_LOGGER = logging.getLogger(__name__)

# Voice biometrics configuration
# MQTT Configuration (from environment variables for Docker)
import os

MQTT_BROKER = os.getenv('MQTT_BROKER', 'localhost')
MQTT_PORT = int(os.getenv('MQTT_PORT', '1883'))
MQTT_USER = os.getenv('MQTT_USER', 'mqtt-user')
MQTT_PASS = os.getenv('MQTT_PASS', '')
VOICEBM_CONTAINER_BASE = os.getenv("VOICEBM_CONTAINER_BASE", "/opt/voicebm")
VOICEBM_HOST_BASE = os.getenv("VOICEBM_HOST_BASE", "/opt/voicebm")
SHARED_AUDIO_DIR = os.path.join(VOICEBM_CONTAINER_BASE, "stt_requests")
VB_REQUEST_TOPIC = "voicebm/stt/analyze_request"
VB_RESPONSE_TOPIC = "voicebm/stt/analyze_response"
VB_BIOPSY_REQUEST_TOPIC = "voicebm/stt/biopsy_request"  # NEW: Early biopsy
ANALYSIS_TIMEOUT = 20  # seconds to wait for voice biometrics response
# How much of the utterance to send to VoiceBM for active matching (in seconds)
BIOPSY_SECONDS = float(os.getenv("VB_BIOPSY_SECONDS", "2.0"))
# Biopsy starts this many ms AFTER the audio starts: the first N ms (the wake
# sound) are discarded so the chime stays out of the identity sample. Full STT
# WAV is untouched.
BIOPSY_LEAD_SKIP_MS = int(os.getenv("VB_BIOPSY_LEAD_SKIP_MS", "500"))


class NemoAsrEventHandler(AsyncEventHandler):
    """Event handler for clients."""

    def __init__(
        self,
        wyoming_info: Info,
        models: dict[str, AsrAdapter],
        model_lock: asyncio.Lock,
        *args,
        initial_prompt: Optional[str] = None,
        **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)

        self.wyoming_info_event = wyoming_info.event()
        self.models = models
        self.model_lock = model_lock
        self.initial_prompt = initial_prompt
        self.request_language: Optional[str] = None
        self._wav_dir = tempfile.TemporaryDirectory()
        self._wav_path = os.path.join(self._wav_dir.name, "speech.wav")
        self._wav_file: Optional[wave.Wave_write] = None
        
        # Create shared directory if it doesn't exist
        Path(SHARED_AUDIO_DIR).mkdir(parents=True, exist_ok=True)
        
        # Track injection state (default: ON)
        # Note: This is a fallback - actual state comes from voicebm_stt_service response
        self.inject_identity_enabled = True
        self._injection_state_initialized = False
        
        
        # Streaming biopsy tracking
        self._biopsy_sent = False
        self._biopsy_frames_written = 0
        self._biopsy_frames_skipped = 0
        self._current_request_id = None
        self._biopsy_wav_file: Optional[wave.Wave_write] = None
        self._biopsy_wav_path: Optional[str] = None
        self._audio_format = None
        
        # Subscribe to injection toggle via MQTT (for local fallback)
        self._setup_mqtt_subscription()
        
        _LOGGER.info(f"Voice biometrics MQTT integration initialized")
    
    def _setup_mqtt_subscription(self):
        """Subscribe to injection toggle state via MQTT."""
        try:
            def on_connect(client, userdata, flags, reason_code, properties):
                if reason_code == 0:
                    # Only log initial connection, not reconnects
                    if not self._injection_state_initialized:
                        _LOGGER.info(f"Injection state MQTT connected")
                    client.subscribe("voicebm/living/inject_identity", qos=1)
            
            def on_message(client, userdata, msg):
                try:
                    state = msg.payload.decode('utf-8')
                    new_enabled = (state == "ON")
                    
                    # Only log if state actually changed or this is initial setup
                    if not self._injection_state_initialized:
                        self.inject_identity_enabled = new_enabled
                        self._injection_state_initialized = True
                        _LOGGER.info(f"[SETTING] Initial injection state: {state} (enabled={new_enabled})")
                    elif self.inject_identity_enabled != new_enabled:
                        self.inject_identity_enabled = new_enabled
                        _LOGGER.info(f"[SETTING] Injection state changed: {state} (enabled={new_enabled})")
                    # Otherwise, ignore duplicate retained messages
                    
                except Exception as e:
                    _LOGGER.error(f"Failed to parse injection state: {e}")
            
            def on_disconnect(client, userdata, flags, reason_code, properties):
                # Only log unexpected disconnects, and attempt reconnect
                if reason_code != 0:
                    _LOGGER.warning(f"Injection state MQTT disconnected: rc={reason_code}, will auto-reconnect")
            
            # Create persistent MQTT client for state tracking
            self.state_client = mqtt.Client(
                client_id="wyoming_vb_state",
                clean_session=True,
                callback_api_version=mqtt.CallbackAPIVersion.VERSION2
            )
            self.state_client.username_pw_set(MQTT_USER, MQTT_PASS)
            self.state_client.on_connect = on_connect
            self.state_client.on_message = on_message
            self.state_client.on_disconnect = on_disconnect
            
            # Set reconnect delay and keep-alive
            self.state_client.reconnect_delay_set(min_delay=5, max_delay=300)
            
            # Connect with longer keep-alive to prevent timeouts
            self.state_client.connect(MQTT_BROKER, MQTT_PORT, keepalive=300)
            self.state_client.loop_start()
            
            _LOGGER.info("Subscribed to injection state topic")
            
        except Exception as e:
            _LOGGER.error(f"Failed to setup injection state subscription: {e}")
            self.inject_identity_enabled = True  # Default to ON on error

    def request_voice_analysis(self, audio_path, request_id=None):
        """
        Request voice biometrics analysis via MQTT.
        
        Returns tuple of 5 values:
            (speaker_id, display_name, confidence, inject_enabled, is_blocked)
        
        speaker_id and display_name come from speaker identification gallery matching.
        If no match, they will be None (not hardcoded to "user").
        
        IMPORTANT: is_blocked comes from HOST service (voicebm_stt_service.py)
        which has access to metadata files. This container does NOT have
        access to {VOICEBM_HOST_BASE}/enroll/ filesystem.
        """
        request_id = str(uuid.uuid4())
        response_data = {
            "received": False,
            "speaker_id": None,
            "display_name": None,
            "confidence": 0.0,
            "inject_enabled": True,  # Default
            "is_blocked": False       # Default - HOST service provides actual value
        }
        
        def on_connect(client, userdata, flags, reason_code, properties):
            _LOGGER.info(f"VB MQTT connected: rc={reason_code}")
            client.subscribe(f"{VB_RESPONSE_TOPIC}/{request_id}", qos=1)
        
        def on_message(client, userdata, msg):
            try:
                payload = json.loads(msg.payload.decode('utf-8'))
                response_data["received"] = True
                response_data["speaker_id"] = payload.get("speaker_id")
                response_data["display_name"] = payload.get("display_name")
                response_data["confidence"] = payload.get("confidence", 0.0)
                response_data["inject_enabled"] = payload.get("inject_enabled", True)
                response_data["is_blocked"] = payload.get("is_blocked", False)
                _LOGGER.info(f"VB response: {payload}")
            except Exception as e:
                _LOGGER.error(f"Failed to parse VB response: {e}")
        
        try:
            client = mqtt.Client(
                client_id=f"wyoming_vb_{request_id[:8]}", 
                clean_session=True, 
                callback_api_version=mqtt.CallbackAPIVersion.VERSION2
            )
            client.username_pw_set(MQTT_USER, MQTT_PASS)
            client.on_connect = on_connect
            client.on_message = on_message
            
            client.connect(MQTT_BROKER, MQTT_PORT, 60)
            client.loop_start()
            
            # Wait for subscription
            time.sleep(0.5)
            
            # Publish analysis request
            request_payload = {
                "request_id": request_id,
                "audio_path": audio_path,
                "timestamp": time.time()
            }
            
            _LOGGER.info(f"Publishing VB request: {request_payload}")
            client.publish(VB_REQUEST_TOPIC, json.dumps(request_payload), qos=1)
            
            # Wait for response
            start_time = time.time()
            while not response_data["received"] and (time.time() - start_time) < ANALYSIS_TIMEOUT:
                time.sleep(0.1)
            
            client.loop_stop()
            client.disconnect()
            
            if response_data["received"]:
                return (
                    response_data["speaker_id"], 
                    response_data["display_name"],
                    response_data["confidence"],
                    response_data["inject_enabled"],
                    response_data["is_blocked"]
                )
            else:
                _LOGGER.warning(f"VB analysis timeout after {ANALYSIS_TIMEOUT}s")
                return None, None, 0.0, True, False
                
        except Exception as e:
            _LOGGER.error(f"VB request failed: {e}", exc_info=True)
            return None, None, 0.0, True, False

    def publish_voice_on(self, person_id):
        """
        Publish ON to person's voice binary sensor via MQTT.
        GROUND TRUTH LAYER - Always fires regardless of blocklist.
        
        person_id comes from speaker identification gallery match (e.g., "jane_smith")
        or "user" if no match above threshold.
        """
        try:
            client = mqtt.Client(callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
            client.username_pw_set(MQTT_USER, MQTT_PASS)
            
            client.connect(MQTT_BROKER, MQTT_PORT, 60)
            client.loop_start()
            
            topic = f"{person_id}/voice"
            client.publish(topic, "ON", qos=1, retain=False)
            
            time.sleep(0.3)
            
            client.loop_stop()
            client.disconnect()
            
            _LOGGER.info(f"[OK] Binary sensor ON: {topic}")
            return True
            
        except Exception as e:
            _LOGGER.error(f"Voice sensor MQTT publish failed: {e}")
            return False

    def publish_current_speaker(self, display_name):
        """
        Publish current speaker to global text sensor.
        
        display_name comes from speaker identification gallery match (e.g., "Jane Smith")
        or "user" if no match above threshold. This is the IDENTIFIED speaker 
        from the gallery, not a hardcoded value.
        
        Topic: voicebm/living/current_speaker
        """
        try:
            client = mqtt.Client(callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
            client.username_pw_set(MQTT_USER, MQTT_PASS)
            
            client.connect(MQTT_BROKER, MQTT_PORT, 60)
            client.loop_start()
            
            topic = "voicebm/living/current_speaker"
            client.publish(topic, display_name or "user", qos=1, retain=True)
            
            time.sleep(0.3)
            
            client.loop_stop()
            client.disconnect()
            
            _LOGGER.info(f"[OK] Current speaker: {display_name or 'user'}")
            return True
            
        except Exception as e:
            _LOGGER.error(f"Current speaker publish failed: {e}")
            return False

    async def handle_event(self, event: Event) -> bool:
        if AudioChunk.is_type(event.type):
            chunk = AudioChunk.from_event(event)

            # Initialize full WAV + biopsy on first chunk
            if self._wav_file is None:
                # Full WAV for STT
                self._wav_file = wave.open(self._wav_path, "wb")
                self._wav_file.setframerate(chunk.rate)
                self._wav_file.setsampwidth(chunk.width)
                self._wav_file.setnchannels(chunk.channels)
                
                # Store audio format
                self._audio_format = {
                    'rate': chunk.rate,
                    'width': chunk.width,
                    'channels': chunk.channels
                }
                
                # Generate request ID
                self._current_request_id = str(uuid.uuid4())
                
                # Initialize biopsy WAV
                self._biopsy_sent = False
                self._biopsy_frames_written = 0
                self._biopsy_frames_skipped = 0
                biopsy_filename = f"stt_{int(time.time() * 1000)}_biopsy.wav"
                self._biopsy_wav_path = os.path.join(SHARED_AUDIO_DIR, biopsy_filename)
                self._biopsy_wav_file = wave.open(self._biopsy_wav_path, "wb")
                self._biopsy_wav_file.setframerate(chunk.rate)
                self._biopsy_wav_file.setsampwidth(chunk.width)
                self._biopsy_wav_file.setnchannels(chunk.channels)
                
                _LOGGER.info(f"[STREAMING] New utterance, request_id={self._current_request_id}")

            # ALWAYS write to full WAV
            self._wav_file.writeframes(chunk.audio)
            
            # Write to biopsy if still collecting
            if not self._biopsy_sent and self._biopsy_wav_file is not None:
                biopsy_frames_needed = int(BIOPSY_SECONDS * self._audio_format['rate'])
                biopsy_frames_skip = int((BIOPSY_LEAD_SKIP_MS / 1000.0) * self._audio_format['rate'])
                bytes_per_frame = self._audio_format['width'] * self._audio_format['channels']
                chunk_frames = len(chunk.audio) // bytes_per_frame

                # Discard the first BIOPSY_LEAD_SKIP_MS (the wake sound) before
                # collecting. A chunk may straddle the boundary: skip its head,
                # collect the tail.
                offset_frames = 0
                if self._biopsy_frames_skipped < biopsy_frames_skip:
                    skip_now = min(chunk_frames, biopsy_frames_skip - self._biopsy_frames_skipped)
                    self._biopsy_frames_skipped += skip_now
                    offset_frames = skip_now

                available_frames = chunk_frames - offset_frames
                frames_to_write = min(available_frames, biopsy_frames_needed - self._biopsy_frames_written)
                
                if frames_to_write > 0:
                    start_byte = offset_frames * bytes_per_frame
                    bytes_to_write = frames_to_write * bytes_per_frame
                    self._biopsy_wav_file.writeframes(chunk.audio[start_byte:start_byte + bytes_to_write])
                    self._biopsy_frames_written += frames_to_write
                
                # Check if biopsy complete
                if self._biopsy_frames_written >= biopsy_frames_needed:
                    self._send_early_biopsy()
            
            return True

        if AudioStop.is_type(event.type):
            _LOGGER.debug(
                "Audio stopped. Processing with voice biometrics first.",
            )
            assert self._wav_file is not None

            self._wav_file.close()
            self._wav_file = None
            
            # Close biopsy if somehow still open
            if self._biopsy_wav_file is not None:
                self._biopsy_wav_file.close()
                self._biopsy_wav_file = None

            # ============================================================
            # STEP 1: VOICE BIOMETRICS FIRST (before any STT)
            # ============================================================
            speaker_id = None
            display_name = None
            confidence = 0.0
            inject_enabled = True
            is_blocked = False
            
            try:
                vb_pipeline_start = time.time()
                _LOGGER.info(f"[TIMING] STEP 1: Voice biometrics analysis FIRST... (t={vb_pipeline_start:.3f})")
                
                # Copy audio to shared location (BIOPSY: only first N seconds for active matching)
                shared_audio_filename = f"stt_{int(time.time() * 1000)}.wav"
                shared_audio_path = os.path.join(
                    SHARED_AUDIO_DIR, 
                    shared_audio_filename
                )
                
                # Full WAV for STT
                shutil.copy2(self._wav_path, shared_audio_path)
                
                # HOST path for voicebm_stt_service.py
                host_audio_path = f"{VOICEBM_HOST_BASE}/stt_requests/{shared_audio_filename}"
                
                # Request analysis via MQTT - returns gallery match results
                mqtt_request_start = time.time()
                _LOGGER.info(f"[TIMING] Requesting VoiceBM analysis via MQTT... (t={mqtt_request_start:.3f})")
                
                speaker_id, display_name, confidence, inject_enabled, is_blocked = self.request_voice_analysis(
                    host_audio_path,
                    request_id=self._current_request_id  # Use same ID from biopsy
                )
                
                mqtt_response_end = time.time()
                mqtt_roundtrip_ms = (mqtt_response_end - mqtt_request_start) * 1000
                _LOGGER.info(f"[TIMING] VoiceBM MQTT round-trip completed in {mqtt_roundtrip_ms:.2f}ms")
                
                # ============================================================
                # speaker_id/display_name come from speaker identification comparison 
                # against enrolled gallery - this is WHO was identified
                # ============================================================
                final_speaker_id = speaker_id or "user"
                final_display_name = display_name or "user"
                
                _LOGGER.info(f"[IDENTIFIED] {final_display_name} (speaker_id={final_speaker_id}, confidence={confidence:.4f}, blocked={is_blocked})")
                
                # ============================================================
                # STEP 2: BINARY SENSOR ALWAYS FIRES (Ground Truth Layer)
                # Fires the sensor for whoever speaker identification identified
                # ============================================================
                self.publish_voice_on(final_speaker_id)
                
                # ============================================================
                # STEP 3: UPDATE CURRENT SPEAKER TEXT SENSOR
                # This shows WHO speaker identification identified from the gallery
                # ============================================================
                self.publish_current_speaker(final_display_name)
                
                vb_pipeline_end = time.time()
                vb_total_time_ms = (vb_pipeline_end - vb_pipeline_start) * 1000
                _LOGGER.info(f"[TIMING] ✅ Voice biometrics pipeline COMPLETE in {vb_total_time_ms:.2f}ms (biopsy + MQTT + sensors)")
                
                # ============================================================
                # STEP 4: IF BLOCKED - STOP EVERYTHING HERE
                # ============================================================
                if is_blocked:
                    _LOGGER.info(f"[BLOCKED] {final_display_name} ({final_speaker_id}) is on blocklist - NO STT, NO MQTT, returning empty")
                    
                    # Canonical mirrors the HA return path: blocked -> "" (cleared,
                    # not left stale). Mirrors exactly what HA receives below.
                    try:
                        _cc = mqtt.Client(client_id="wyoming_asr_canon", clean_session=True, callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
                        _cc.username_pw_set(MQTT_USER, MQTT_PASS)
                        _cc.connect(MQTT_BROKER, MQTT_PORT, 60)
                        _cc.publish("voicebm/transcript/preferred", "", qos=1, retain=True)
                        _cc.disconnect()
                    except Exception as e:
                        _LOGGER.error(f"Canonical clear failed: {e}")
                    
                    # Cleanup shared audio file
                    try:
                        os.unlink(shared_audio_path)
                    except:
                        pass
                    
                    # Return empty transcript - skip all processing
                    await self.write_event(Transcript(text="").event())
                    self.request_language = None
                    return False
                
                # ============================================================
                # STEP 5: NOT BLOCKED - Do STT transcription
                # ============================================================
                stt_start = time.time()
                _LOGGER.info(f"[TIMING] STEP 5: Not blocked - proceeding with STT... (t={stt_start:.3f})")
                
                # Read audio for STT
                waveform, sample_rate = sf.read(self._wav_path, dtype="float32")
                if len(waveform.shape) > 1:
                    waveform = np.mean(waveform, axis=1)

                lang = self.request_language or "en"
                model = None

                if lang == "en" and "en" in self.models:
                    model = self.models["en"]
                elif "multi" in self.models:
                    model = self.models["multi"]
                elif "en" in self.models:
                    model = self.models["en"]

                if model is None:
                    await self.write_event(Transcript(text="ERROR: No model").event())
                    return False

                async with self.model_lock:
                    try:
                        # STT transcription
                        text = model.recognize(
                            waveform, language=lang, sample_rate=sample_rate
                        )
                        stt_end = time.time()
                        stt_duration_ms = (stt_end - stt_start) * 1000
                        _LOGGER.info(f"[TIMING] STT transcription completed in {stt_duration_ms:.2f}ms")
                        _LOGGER.info(f"TRANSCRIPTION: '{text}'")

                        # ============================================================
                        # STEP 6: Apply injection if enabled
                        # Uses display_name from GALLERY MATCH
                        # ============================================================
                        if inject_enabled:
                            if display_name:
                                modified_text = f"{display_name}: {text}"
                            else:
                                modified_text = f"user: {text}"
                            _LOGGER.info(f"[INJECTED] '{modified_text}'")
                        else:
                            modified_text = text
                            _LOGGER.info(f"[CLEAN] '{modified_text}' (injection disabled)")

                        # ============================================================
                        # STEP 7: Publish to MQTT
                        # ============================================================
                        try:
                            msg = {
                                "state": "user_transcript_ready",
                                "full": modified_text.strip() if modified_text else "",
                                "timestamp": __import__('datetime').datetime.now().isoformat()
                            }

                            _LOGGER.info(f"MQTT PUBLISH: topic=voicebm/transcript/debug, payload={json.dumps(msg)}")
                            
                            mqtt_client = mqtt.Client(client_id="wyoming_asr", clean_session=True, callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
                            mqtt_client.username_pw_set(MQTT_USER, MQTT_PASS)
                            
                            def on_connect(client, userdata, flags, reason_code, properties):
                                _LOGGER.info(f"MQTT CONNECT: rc={reason_code}")
                                
                            def on_publish(client, userdata, mid, reason_code, properties):
                                _LOGGER.info(f"MQTT PUBLISH SUCCESS: mid={mid}")
                                
                            def on_disconnect(client, userdata, flags, reason_code, properties):
                                _LOGGER.info(f"MQTT DISCONNECT: rc={reason_code}")
                            
                            mqtt_client.on_connect = on_connect
                            mqtt_client.on_publish = on_publish
                            mqtt_client.on_disconnect = on_disconnect
                            
                            mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)
                            
                            result = mqtt_client.publish("voicebm/transcript/debug", json.dumps(msg), qos=1, retain=True)
                            mqtt_client.publish("voicebm/transcript/preferred", modified_text, qos=1, retain=True)
                            
                            mqtt_client.loop_start()
                            result.wait_for_publish(timeout=5)
                            mqtt_client.loop_stop()
                            
                            mqtt_client.disconnect()
                            _LOGGER.info(f"MQTT COMPLETE: {modified_text.strip() if modified_text else ''}")
                        except Exception as e:
                            _LOGGER.error(f"MQTT FAILED: {e}", exc_info=True)

                    except Exception as e:
                        _LOGGER.error(f"RECOGNITION FAILED: {e}")
                        await self.write_event(Transcript(text="ERROR: Recognition failed").event())
                        return False
                
                # ============================================================
                # TIMING SUMMARY: Complete end-to-end pipeline
                # ============================================================
                total_end = time.time()
                total_time_ms = (total_end - vb_pipeline_start) * 1000
                _LOGGER.info(f"[TIMING] 🏁 END-TO-END COMPLETE in {total_time_ms:.2f}ms (VoiceBM + STT + MQTT)")

                # Cleanup shared audio file
                try:
                    os.unlink(shared_audio_path)
                except:
                    pass

                # Return transcript
                await self.write_event(Transcript(text=modified_text).event())
                self.request_language = None
                return False

            except Exception as e:
                _LOGGER.error(f"Voice biometrics error: {e}", exc_info=True)
                # On error, fall back to basic STT without identity
                
                waveform, sample_rate = sf.read(self._wav_path, dtype="float32")
                if len(waveform.shape) > 1:
                    waveform = np.mean(waveform, axis=1)

                lang = self.request_language or "en"
                model = self.models.get("en") or self.models.get("multi")
                
                if model:
                    async with self.model_lock:
                        text = model.recognize(waveform, language=lang, sample_rate=sample_rate)
                        # Fallback uses local inject state
                        if self.inject_identity_enabled:
                            await self.write_event(Transcript(text=f"user: {text}").event())
                        else:
                            await self.write_event(Transcript(text=text).event())
                else:
                    await self.write_event(Transcript(text="").event())
                
                self.request_language = None
                return False

        if Transcribe.is_type(event.type):
            transcribe = Transcribe.from_event(event)
            self.request_language = transcribe.language
            return True

        if Describe.is_type(event.type):
            await self.write_event(self.wyoming_info_event)
            return True

        return True
    def _send_early_biopsy(self):
        """Close biopsy WAV and send MQTT request WHILE user is still speaking."""
        if self._biopsy_sent or self._biopsy_wav_file is None:
            return
        
        try:
            # Close biopsy
            self._biopsy_wav_file.close()
            self._biopsy_wav_file = None
            
            # Convert container path to host path
            host_biopsy_path = self._biopsy_wav_path.replace(VOICEBM_CONTAINER_BASE, VOICEBM_HOST_BASE)
            
            # Send biopsy request
            biopsy_request = {
                "request_id": self._current_request_id,
                "room": "active",
                "biopsy_path": host_biopsy_path
            }
            
            if hasattr(self, 'injection_mqtt_client') and self.injection_mqtt_client:
                self.injection_mqtt_client.publish(
                    VB_BIOPSY_REQUEST_TOPIC,
                    json.dumps(biopsy_request),
                    qos=1
                )
            
            self._biopsy_sent = True
            _LOGGER.info(f"[STREAMING] ⚡ Biopsy sent at {BIOPSY_SECONDS}s (user still speaking)")
            
        except Exception as e:
            _LOGGER.error(f"[STREAMING] Biopsy send failed: {e}")
            self._biopsy_sent = True



