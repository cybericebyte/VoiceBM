#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# VoiceBM v2.0 - Global Services Deployment Script
# =============================================================================
# Purpose: Deploy all global VoiceBM services with path-agnostic configuration
#
# What it does:
# 1. Reads config.json for all paths and credentials
# 2. Detects install user dynamically
# 3. Deploys voicebm_config.py (centralized configuration)
# 4. Renders Python service templates
# 5. Renders shell script templates
# 6. Renders systemd service templates
# 7. Copies rendered services to systemd
# 8. Deploys handler.py into the ONNX ASR Docker container
# 9. Enables and starts all services
# 10. Verifies startup
#
# Usage: sudo ./deploy_global_services.sh
# =============================================================================

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}VoiceBM v2.0 - Global Services Deployment${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# =============================================================================
# CONFIGURATION DETECTION
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [[ -f "../config.json" ]]; then
    CONFIG_FILE="../config.json"
elif [[ -f "./config.json" ]]; then
    CONFIG_FILE="./config.json"
else
    echo -e "${RED}ERROR: config.json not found${NC}"
    echo "Expected location: ../config.json or ./config.json"
    exit 1
fi

echo -e "${GREEN}✓${NC} Found config.json: $CONFIG_FILE"

if [[ -n "${SUDO_USER:-}" ]]; then
    INSTALL_USER="$SUDO_USER"
else
    INSTALL_USER="$(whoami)"
fi

echo -e "${GREEN}✓${NC} Install user: $INSTALL_USER"

TEMPLATES_DIR="../templates/global"
if [[ ! -d "$TEMPLATES_DIR" ]]; then
    echo -e "${RED}ERROR: Templates directory not found: $TEMPLATES_DIR${NC}"
    exit 1
fi

echo -e "${GREEN}✓${NC} Templates directory: $TEMPLATES_DIR"
echo ""

# =============================================================================
# EXTRACT CONFIGURATION VALUES
# =============================================================================

echo -e "${YELLOW}Reading configuration...${NC}"

MQTT_BROKER=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['mqtt']['broker'])")
MQTT_PORT=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['mqtt']['port'])")
MQTT_USER=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['mqtt']['user'])")
MQTT_PASS=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['mqtt']['password'])")

VOICEBM_BASE=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['paths']['voicebm_base'])")
SHERPA_BIN=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['paths']['sherpa_bin'])")
SHERPA_MODEL=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['paths']['sherpa_model'])")
CONDA_PATH=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['paths']['conda_path'])")

AUDIO_HOST=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['audio_server']['host'])")
AUDIO_PORT=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['audio_server']['port'])")

# ONNX ASR source: where handler.py lives on the host before docker cp
ONNX_ASR_SOURCE=$(python3 -c "
import json
c = json.load(open('$CONFIG_FILE'))
print(c.get('paths', {}).get('onnx_asr_source', ''))
" 2>/dev/null || echo "")

if [[ -z "$ONNX_ASR_SOURCE" ]]; then
    ONNX_ASR_SOURCE="$(dirname "$VOICEBM_BASE")/onnx-asr-addon/onnx-asr"
    echo -e "${YELLOW}  ⚠${NC} onnx_asr_source not in config.json — inferring: $ONNX_ASR_SOURCE"
fi

echo -e "${GREEN}✓${NC} MQTT Broker: $MQTT_BROKER:$MQTT_PORT"
echo -e "${GREEN}✓${NC} VoiceBM Base: $VOICEBM_BASE"
echo -e "${GREEN}✓${NC} Sherpa Binary: $SHERPA_BIN"
echo -e "${GREEN}✓${NC} Sherpa Model: $SHERPA_MODEL"
echo -e "${GREEN}✓${NC} Conda Path: $CONDA_PATH"
echo -e "${GREEN}✓${NC} Audio Server: $AUDIO_HOST:$AUDIO_PORT"
echo -e "${GREEN}✓${NC} ONNX ASR Source: $ONNX_ASR_SOURCE"
echo ""

# =============================================================================
# ESCAPE SPECIAL CHARACTERS FOR SED
# =============================================================================

escape_sed() {
    echo "$1" | sed -e 's/[\/&]/\\&/g' -e 's/$/\\n/' | tr -d '\n'
}

MQTT_BROKER_ESC=$(escape_sed "$MQTT_BROKER")
MQTT_USER_ESC=$(escape_sed "$MQTT_USER")
MQTT_PASS_ESC=$(escape_sed "$MQTT_PASS")
AUDIO_HOST_ESC=$(escape_sed "$AUDIO_HOST")
VOICEBM_BASE_ESC=$(escape_sed "$VOICEBM_BASE")
SHERPA_BIN_ESC=$(escape_sed "$SHERPA_BIN")
SHERPA_MODEL_ESC=$(escape_sed "$SHERPA_MODEL")
CONDA_PATH_ESC=$(escape_sed "$CONDA_PATH")

# =============================================================================
# RENDER TEMPLATE FUNCTION
# =============================================================================

render_template() {
    local template_file="$1"
    local output_file="$2"

    if [[ ! -f "$template_file" ]]; then
        echo -e "${RED}ERROR: Template not found: $template_file${NC}"
        return 1
    fi

    sed -e "s|{MQTT_BROKER}|${MQTT_BROKER_ESC}|g" \
        -e "s|{MQTT_PORT}|${MQTT_PORT}|g" \
        -e "s|{MQTT_USER}|${MQTT_USER_ESC}|g" \
        -e "s|{MQTT_PASS}|${MQTT_PASS_ESC}|g" \
        -e "s|{AUDIO_HOST}|${AUDIO_HOST_ESC}|g" \
        -e "s|{AUDIO_PORT}|${AUDIO_PORT}|g" \
        -e "s|{VOICEBM_BASE}|${VOICEBM_BASE_ESC}|g" \
        -e "s|{SHERPA_BIN}|${SHERPA_BIN_ESC}|g" \
        -e "s|{SHERPA_MODEL}|${SHERPA_MODEL_ESC}|g" \
        -e "s|{CONDA_PATH}|${CONDA_PATH_ESC}|g" \
        -e "s|{INSTALL_USER}|${INSTALL_USER}|g" \
        "$template_file" > "$output_file"

    echo -e "${GREEN}  ✓${NC} $(basename "$output_file")"
}

# =============================================================================
# DEPLOY voicebm_config.py (CRITICAL - MUST BE FIRST)
# =============================================================================

echo -e "${YELLOW}Deploying voicebm_config.py (centralized configuration)...${NC}"

render_template \
    "$TEMPLATES_DIR/voicebm_config.py.template" \
    "$VOICEBM_BASE/voicebm_config.py"

chown $INSTALL_USER:$INSTALL_USER "$VOICEBM_BASE/voicebm_config.py"
chmod 644 "$VOICEBM_BASE/voicebm_config.py"

echo -e "${GREEN}✓${NC} voicebm_config.py deployed"
echo ""

# =============================================================================
# DEPLOY PYTHON SERVICES
# =============================================================================

echo -e "${YELLOW}Deploying Python services...${NC}"

mkdir -p "$VOICEBM_BASE/bin"

PYTHON_SERVICES=(
    "voicebm_stt_service.py"
    "voicebm_global_publisher.py"
    "audio_server.py"
    "cluster_publisher.py"
    "enrollment_watcher.py"
    "mqtt_commands.py"
    "vad_filter.py"
    "retention.py"
    "cleanup_recordings.py"
    "voice_clustering.py"
    "mqtt_publisher.py"
    "enroll_suggest_living.py"
    "publish_identity_living.py"
    "publish_living_mqtt.py"
    "thing_engine.py"
    "voicebm_dashboard.py"
)

for service in "${PYTHON_SERVICES[@]}"; do
    template_file="$TEMPLATES_DIR/${service}.template"
    output_file="$VOICEBM_BASE/bin/$service"

    if [[ -f "$template_file" ]]; then
        render_template "$template_file" "$output_file"
        chown $INSTALL_USER:$INSTALL_USER "$output_file"
        chmod 755 "$output_file"
    else
        echo -e "${YELLOW}  ⚠${NC} Template not found: $service (skipping)"
    fi
done

echo ""

# =============================================================================
# DEPLOY SHELL SCRIPTS
# =============================================================================

echo -e "${YELLOW}Deploying shell scripts...${NC}"

SHELL_SCRIPTS=(
    "embed_stt.sh"
    "approve.sh"
)

for script in "${SHELL_SCRIPTS[@]}"; do
    template_file="$TEMPLATES_DIR/${script}.template"
    output_file="$VOICEBM_BASE/bin/$script"

    if [[ -f "$template_file" ]]; then
        render_template "$template_file" "$output_file"
        chown $INSTALL_USER:$INSTALL_USER "$output_file"
        chmod 755 "$output_file"
    else
        echo -e "${YELLOW}  ⚠${NC} Template not found: $script (skipping)"
    fi
done

# Copy sherpa_embed.py wrapper (not a template)
if [[ -f "$TEMPLATES_DIR/sherpa_embed.py" ]]; then
    cp "$TEMPLATES_DIR/sherpa_embed.py" "$SHERPA_BIN"
    chown $INSTALL_USER:$INSTALL_USER "$SHERPA_BIN"
    chmod 755 "$SHERPA_BIN"
    echo -e "${GREEN}  ✓${NC} sherpa_embed.py (wrapper)"
fi

echo ""

# =============================================================================
# DEPLOY SYSTEMD SERVICES
# =============================================================================

echo -e "${YELLOW}Deploying systemd services...${NC}"

SYSTEMD_SERVICES=(
    "voicebm-stt.service"
    "voicebm-global-publisher.service"
    "voicebm-audio-server.service"
    "voicebm-cluster-publisher.service"
    "voicebm-enrollment-watcher.service"
    "voicebm-commands.service"
    "voicebm-retention.service"
    "voicebm-vad.service"
    "voicebm-cleanup.service"
    "voicebm-wav-http.service"
    "voicebm-thing-engine.service"
    "voicebm-dashboard.service"
)

for service in "${SYSTEMD_SERVICES[@]}"; do
    template_file="$TEMPLATES_DIR/${service}.template"
    output_file="/tmp/${service}"

    if [[ -f "$template_file" ]]; then
        render_template "$template_file" "$output_file"
        mv "$output_file" "/etc/systemd/system/$service"
        chmod 644 "/etc/systemd/system/$service"
    else
        echo -e "${YELLOW}  ⚠${NC} Template not found: $service (skipping)"
    fi
done

# Deploy timer
TIMER_FILE="voicebm-cleanup.timer"
if [[ -f "$TEMPLATES_DIR/${TIMER_FILE}.template" ]]; then
    render_template "$TEMPLATES_DIR/${TIMER_FILE}.template" "/tmp/${TIMER_FILE}"
    mv "/tmp/${TIMER_FILE}" "/etc/systemd/system/${TIMER_FILE}"
    chmod 644 "/etc/systemd/system/${TIMER_FILE}"
    echo -e "${GREEN}  ✓${NC} $TIMER_FILE"
fi

echo ""

# =============================================================================
# DEPLOY HANDLER.PY INTO ONNX ASR DOCKER CONTAINER
# =============================================================================

echo -e "${YELLOW}Deploying handler.py to Docker container (nifty_grothendieck)...${NC}"

HANDLER_TEMPLATE="$TEMPLATES_DIR/handler.py.template"
HANDLER_RENDERED="${ONNX_ASR_SOURCE}/handler.py"

if [[ -f "$HANDLER_TEMPLATE" ]]; then
    mkdir -p "$ONNX_ASR_SOURCE"
    render_template "$HANDLER_TEMPLATE" "$HANDLER_RENDERED"
    chown $INSTALL_USER:$INSTALL_USER "$HANDLER_RENDERED"

    echo -e "${YELLOW}  Copying into nifty_grothendieck...${NC}"
    docker cp "$HANDLER_RENDERED" nifty_grothendieck:/app/wyoming_onnx_asr/handler.py
    docker restart nifty_grothendieck
    echo -e "${GREEN}✓${NC} handler.py deployed and container restarted"
else
    echo -e "${RED}  ERROR: handler.py template not found${NC}"
    exit 1
fi

echo ""

# =============================================================================
# ADD VOICEBM TUNABLES TO config.json (if not present)
# =============================================================================

echo -e "${YELLOW}Ensuring config.json has 2.0 tunables...${NC}"

python3 -c "
import json
p = '${VOICEBM_BASE}/config.json'
try:
    with open(p) as f:
        cfg = json.load(f)
    vb = cfg.get('voicebm', {})
    changed = False
    if 'gallery_max' not in vb:
        vb['gallery_max'] = 75; changed = True
    if 'active_lead_trim_ms' not in vb:
        vb['active_lead_trim_ms'] = 0; changed = True
    if changed:
        cfg['voicebm'] = vb
        with open(p, 'w') as f:
            json.dump(cfg, f, indent=2)
        print('  Added voicebm tunables (gallery_max=75, active_lead_trim_ms=0)')
    else:
        print('  voicebm tunables already present')
except FileNotFoundError:
    print('  config.json not at VOICEBM_BASE — copy config.json there if needed')
"

echo ""

# =============================================================================
# RELOAD SYSTEMD AND START SERVICES
# =============================================================================

echo -e "${YELLOW}Reloading systemd daemon...${NC}"
systemctl daemon-reload
echo -e "${GREEN}✓${NC} Systemd reloaded"
echo ""

echo -e "${YELLOW}Enabling and starting services...${NC}"

for service in "${SYSTEMD_SERVICES[@]}"; do
    if systemctl list-unit-files | grep -q "^${service}"; then
        systemctl enable "$service" 2>/dev/null || true
        systemctl restart "$service" 2>/dev/null || true

        sleep 1
        if systemctl is-active --quiet "$service"; then
            echo -e "${GREEN}  ✓${NC} $service"
        else
            echo -e "${RED}  ✗${NC} $service (failed to start)"
        fi
    fi
done

if systemctl list-unit-files | grep -q "^${TIMER_FILE}"; then
    systemctl enable "$TIMER_FILE" 2>/dev/null || true
    systemctl start "$TIMER_FILE" 2>/dev/null || true
    echo -e "${GREEN}  ✓${NC} $TIMER_FILE"
fi

echo ""

# =============================================================================
# VERIFY
# =============================================================================

echo -e "${YELLOW}Verifying MQTT connection...${NC}"

sleep 3

if systemctl is-active --quiet voicebm-global-publisher.service; then
    echo -e "${GREEN}✓${NC} Global publisher is running"
else
    echo -e "${RED}✗${NC} Global publisher failed to start"
    echo "  Check: sudo journalctl -u voicebm-global-publisher.service -n 50 --no-pager"
fi

if systemctl is-active --quiet voicebm-stt.service; then
    echo -e "${GREEN}✓${NC} STT service is running"
else
    echo -e "${RED}✗${NC} STT service failed to start"
    echo "  Check: sudo journalctl -u voicebm-stt.service -n 50 --no-pager"
fi

echo ""

# =============================================================================
# COMPLETION SUMMARY
# =============================================================================

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}VoiceBM v2.0 Deployment Complete${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo "Next steps:"
echo "1. Check service status: sudo systemctl status voicebm-*.service"
echo "2. View logs: sudo journalctl -u voicebm-stt.service -n 50 --no-pager"
echo "3. Check Home Assistant for 'Voice Biometrics' device"
echo "4. Deploy passive nodes: sudo ./replicate_node.sh living"
echo ""
echo "Configuration:"
echo "  Install User : $INSTALL_USER"
echo "  VoiceBM Base : $VOICEBM_BASE"
echo "  MQTT Broker  : $MQTT_BROKER:$MQTT_PORT"
echo ""
