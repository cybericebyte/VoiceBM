#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# VoiceBM v1.0.1 - Passive Node Deployment Script  
# =============================================================================
# Purpose: Deploy room-specific passive voice monitoring node
#
# Usage: sudo ./replicate_node.sh <room_name>
# Example: sudo ./replicate_node.sh living
# =============================================================================

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check if room name provided
if [[ $# -lt 1 ]]; then
    echo -e "${RED}ERROR: Room name required${NC}"
    echo "Usage: sudo ./replicate_node.sh <room_name>"
    echo "Example: sudo ./replicate_node.sh living"
    exit 1
fi

ROOM_NAME="$1"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}VoiceBM v1.0.1 - Deploying Passive Node${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e "Room: ${YELLOW}${ROOM_NAME}${NC}"
echo ""

# Detect script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Find config.json
if [[ -f "../config.json" ]]; then
    CONFIG_FILE="../config.json"
elif [[ -f "./config.json" ]]; then
    CONFIG_FILE="./config.json"
else
    echo -e "${RED}ERROR: config.json not found${NC}"
    exit 1
fi

# Detect install user
if [[ -n "${SUDO_USER:-}" ]]; then
    INSTALL_USER="$SUDO_USER"
else
    INSTALL_USER="$(whoami)"
fi

echo -e "${GREEN}✓${NC} Install user: $INSTALL_USER"
echo -e "${GREEN}✓${NC} Config: $CONFIG_FILE"
echo ""

# Extract configuration
VOICEBM_BASE=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['paths']['voicebm_base'])")
SHERPA_BIN=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['paths']['sherpa_bin'])")
SHERPA_MODEL=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['paths']['sherpa_model'])")
CONDA_PATH=$(python3 -c "import json; print(json.load(open('$CONFIG_FILE'))['paths']['conda_path'])")

# Check if room exists in config
RTSP_URL=$(python3 -c "import json; c=json.load(open('$CONFIG_FILE')); print(c['rooms'].get('$ROOM_NAME', {}).get('rtsp_url', ''))")

if [[ -z "$RTSP_URL" ]]; then
    echo -e "${RED}ERROR: Room '$ROOM_NAME' not found in config.json${NC}"
    echo "Add the room to config.json first under 'rooms' section"
    exit 1
fi

echo -e "${GREEN}✓${NC} Room '$ROOM_NAME' found in config"
echo -e "${GREEN}✓${NC} RTSP URL: $RTSP_URL"
echo ""

# Escape for sed
escape_sed() {
    echo "$1" | sed -e 's/[\/&]/\\&/g' -e 's/$/\\n/' | tr -d '\n'
}

VOICEBM_BASE_ESC=$(escape_sed "$VOICEBM_BASE")
SHERPA_BIN_ESC=$(escape_sed "$SHERPA_BIN")
SHERPA_MODEL_ESC=$(escape_sed "$SHERPA_MODEL")
CONDA_PATH_ESC=$(escape_sed "$CONDA_PATH")
RTSP_URL_ESC=$(escape_sed "$RTSP_URL")

# Create directories
echo -e "${YELLOW}Creating directories...${NC}"
mkdir -p "$VOICEBM_BASE/recordings/$ROOM_NAME"
mkdir -p "$VOICEBM_BASE/embeddings/$ROOM_NAME"
chown -R $INSTALL_USER:$INSTALL_USER "$VOICEBM_BASE/recordings/$ROOM_NAME"
chown -R $INSTALL_USER:$INSTALL_USER "$VOICEBM_BASE/embeddings/$ROOM_NAME"
echo -e "${GREEN}✓${NC} Directories created"
echo ""

# Templates directory
TEMPLATES_DIR="../templates/passive"

# Render template function
render_template() {
    local template_file="$1"
    local output_file="$2"
    
    sed -e "s|{VOICEBM_BASE}|${VOICEBM_BASE_ESC}|g" \
        -e "s|{SHERPA_BIN}|${SHERPA_BIN_ESC}|g" \
        -e "s|{SHERPA_MODEL}|${SHERPA_MODEL_ESC}|g" \
        -e "s|{CONDA_PATH}|${CONDA_PATH_ESC}|g" \
        -e "s|{ROOM}|${ROOM_NAME}|g" \
        -e "s|{RTSP_URL}|${RTSP_URL_ESC}|g" \
        -e "s|{INSTALL_USER}|${INSTALL_USER}|g" \
        "$template_file" > "$output_file"
}

# Deploy recorder script
echo -e "${YELLOW}Deploying recorder script...${NC}"
render_template "$TEMPLATES_DIR/rec_ROOM.sh.template" "$VOICEBM_BASE/bin/rec_${ROOM_NAME}.sh"
chmod 755 "$VOICEBM_BASE/bin/rec_${ROOM_NAME}.sh"
chown $INSTALL_USER:$INSTALL_USER "$VOICEBM_BASE/bin/rec_${ROOM_NAME}.sh"
echo -e "${GREEN}  ✓${NC} rec_${ROOM_NAME}.sh"

# Deploy embedder script
echo -e "${YELLOW}Deploying embedder script...${NC}"
render_template "$TEMPLATES_DIR/embed_ROOM.sh.template" "$VOICEBM_BASE/bin/embed_${ROOM_NAME}.sh"
chmod 755 "$VOICEBM_BASE/bin/embed_${ROOM_NAME}.sh"
chown $INSTALL_USER:$INSTALL_USER "$VOICEBM_BASE/bin/embed_${ROOM_NAME}.sh"
echo -e "${GREEN}  ✓${NC} embed_${ROOM_NAME}.sh"

# Deploy Python services
echo -e "${YELLOW}Deploying Python services...${NC}"
for py_script in publish_identity_ROOM.py publish_mqtt_ROOM.py; do
    output_name=$(echo "$py_script" | sed "s/ROOM/${ROOM_NAME}/g")
    render_template "$TEMPLATES_DIR/$py_script.template" "$VOICEBM_BASE/bin/$output_name"
    chmod 755 "$VOICEBM_BASE/bin/$output_name"
    chown $INSTALL_USER:$INSTALL_USER "$VOICEBM_BASE/bin/$output_name"
    echo -e "${GREEN}  ✓${NC} $output_name"
done
echo ""

# Deploy systemd services
echo -e "${YELLOW}Deploying systemd services...${NC}"

# Recorder service
render_template "$TEMPLATES_DIR/recorder.service.template" "/tmp/voicebm-recorder-${ROOM_NAME}.service"
mv "/tmp/voicebm-recorder-${ROOM_NAME}.service" "/etc/systemd/system/voicebm-recorder-${ROOM_NAME}.service"
echo -e "${GREEN}  ✓${NC} voicebm-recorder-${ROOM_NAME}.service"

# Embedder service
render_template "$TEMPLATES_DIR/embedder.service.template" "/tmp/voicebm-embedder-${ROOM_NAME}.service"
mv "/tmp/voicebm-embedder-${ROOM_NAME}.service" "/etc/systemd/system/voicebm-embedder-${ROOM_NAME}.service"
echo -e "${GREEN}  ✓${NC} voicebm-embedder-${ROOM_NAME}.service"

# Publisher service
render_template "$TEMPLATES_DIR/publisher.service.template" "/tmp/voicebm-publisher-${ROOM_NAME}.service"
mv "/tmp/voicebm-publisher-${ROOM_NAME}.service" "/etc/systemd/system/voicebm-publisher-${ROOM_NAME}.service"
echo -e "${GREEN}  ✓${NC} voicebm-publisher-${ROOM_NAME}.service"
echo ""

# Reload and start services
echo -e "${YELLOW}Starting services...${NC}"
systemctl daemon-reload

systemctl enable "voicebm-recorder-${ROOM_NAME}.service"
systemctl restart "voicebm-recorder-${ROOM_NAME}.service"
sleep 1
if systemctl is-active --quiet "voicebm-recorder-${ROOM_NAME}.service"; then
    echo -e "${GREEN}  ✓${NC} Recorder started"
else
    echo -e "${RED}  ✗${NC} Recorder failed"
fi

systemctl enable "voicebm-embedder-${ROOM_NAME}.service"
systemctl restart "voicebm-embedder-${ROOM_NAME}.service"
sleep 1
if systemctl is-active --quiet "voicebm-embedder-${ROOM_NAME}.service"; then
    echo -e "${GREEN}  ✓${NC} Embedder started"
else
    echo -e "${RED}  ✗${NC} Embedder failed"
fi

systemctl enable "voicebm-publisher-${ROOM_NAME}.service"
systemctl restart "voicebm-publisher-${ROOM_NAME}.service"
sleep 1
if systemctl is-active --quiet "voicebm-publisher-${ROOM_NAME}.service"; then
    echo -e "${GREEN}  ✓${NC} Publisher started"
else
    echo -e "${RED}  ✗${NC} Publisher failed"
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Passive Node Deployed Successfully!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo "Room: $ROOM_NAME"
echo "Services:"
echo "  - voicebm-recorder-${ROOM_NAME}.service"
echo "  - voicebm-embedder-${ROOM_NAME}.service"
echo "  - voicebm-publisher-${ROOM_NAME}.service"
echo ""
echo "Check status: sudo systemctl status voicebm-recorder-${ROOM_NAME}.service"
echo "View logs: sudo journalctl -u voicebm-recorder-${ROOM_NAME}.service -f"
echo ""
