# VoiceBM v1.0.1 - Installation Package

## What's Fixed in v1.0.1

✅ **Removed hardcoded username** - No more `ice:ice` errors  
✅ **Auto-detects install user** - Works on any Linux system  
✅ **Fully path-agnostic** - Install anywhere  

**GitHub Issue:** Fixes #3 - Invalid user: 'ice:ice'

---

## Quick Start

### 1. Extract Package
```bash
tar -xzf VoiceBM_v1.0.1_Complete.tar.gz
cd VoiceBM_v1.0.1_Complete
```

### 2. Create Configuration
```bash
# Copy sample config
cp config.json.sample config.json

# Edit with your details
nano config.json
```

**Important settings to change:**
- `mqtt.broker` - Your MQTT broker IP
- `mqtt.user` - Your MQTT username  
- `mqtt.password` - Your MQTT password
- `paths.voicebm_base` - Where to install (e.g. `/home/youruser/voicebm`)
- `paths.conda_path` - Your conda/miniforge path
- `rooms` - Add your camera RTSP URLs

### 3. Create Installation Directory
```bash
# Create the directory specified in config.json
sudo mkdir -p /home/youruser/voicebm
sudo chown youruser:youruser /home/youruser/voicebm

# Copy config there
sudo cp config.json /home/youruser/voicebm/
```

### 4. Deploy Global Services
```bash
cd scripts
sudo ./deploy_global_services.sh
```

This will:
- Deploy all Python services
- Create systemd services
- Start everything automatically

### 5. Deploy Room Nodes
```bash
# For each room in your config.json
sudo ./replicate_node.sh living
sudo ./replicate_node.sh bedroom
```

### 6. Verify
```bash
# Check services
systemctl status voicebm-*.service

# Check Home Assistant
# Look for "Voice Biometrics" device
```

---

## Prerequisites

Before running deployment:

1. **Install Miniforge/Conda**
   ```bash
   wget https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Linux-x86_64.sh
   bash Miniforge3-Linux-x86_64.sh
   ```

2. **Create conda environment**
   ```bash
   source ~/miniforge3/etc/profile.d/conda.sh
   conda create -n vb python=3.9 -y
   conda activate vb
   pip install paho-mqtt sherpa-onnx --break-system-packages
   ```

3. **Download Sherpa model**
   ```bash
   mkdir -p ~/sherpa_models
   cd ~/sherpa_models
   wget https://github.com/k2-fsa/sherpa-onnx/releases/download/speaker-recongition-models/nemo_en_titanet_small.onnx
   ```

4. **Install sherpa_embed.py wrapper**
   ```bash
   # Copy from templates/global/sherpa_embed.py
   cp templates/global/sherpa_embed.py ~/.local/bin/
   chmod +x ~/.local/bin/sherpa_embed.py
   ```

5. **MQTT Broker**
   - Must have Mosquitto or compatible MQTT broker running
   - Note credentials for config.json

---

## What Changed from v1.0

### Fixed
- All `User=ice` → `User={INSTALL_USER}` in service templates
- All `ice:ice` → `$USER:$USER` in Python scripts
- Deploy script now auto-detects user with `${SUDO_USER:-$(whoami)}`
- All ownership operations use detected user

### Files Changed
- `scripts/deploy_global_services.sh` - Complete rewrite
- All 16 systemd service templates - User field fixed
- `templates/global/enrollment_watcher.py.template` - chown hint fixed

---

## Troubleshooting

**Services failing to start?**
```bash
# Check logs
sudo journalctl -u voicebm-stt.service -n 50

# Verify config paths
cat /home/youruser/voicebm/voicebm_config.py
```

**Permission errors?**
```bash
# Fix ownership
sudo chown -R youruser:youruser /home/youruser/voicebm
```

**MQTT connection failed?**
```bash
# Test MQTT broker
mosquitto_sub -h 10.50.60.59 -u mqtt-user -P password -t '#' -v
```

---

## Support

- GitHub: https://github.com/cybericebyte/VoiceBM
- Issues: https://github.com/cybericebyte/VoiceBM/issues
- Docs: See templates and service files for details

---

**Version:** 1.0.1  
**Release Date:** January 2, 2026  
**Fixes:** GitHub Issue #3
